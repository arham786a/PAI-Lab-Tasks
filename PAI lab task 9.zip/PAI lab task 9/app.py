from flask import Flask, jsonify, render_template, request
import requests

app = Flask(__name__)

GUARDIAN_API_URL = "https://content.guardianapis.com/search"
GUARDIAN_API_KEY = "test"


def fetch_news(query=None, section=None, page_size=12):
    params = {
        "api-key": GUARDIAN_API_KEY,
        "order-by": "newest",
        "page-size": page_size,
        "show-fields": "trailText,thumbnail,bodyText",
    }
    if query:
        params["q"] = query
    if section and section != "all":
        params["section"] = section

    response = requests.get(GUARDIAN_API_URL, params=params, timeout=10)
    response.raise_for_status()
    data = response.json()
    results = data.get("response", {}).get("results", [])

    articles = []
    for item in results:
        fields = item.get("fields", {})
        articles.append({
            "title": item.get("webTitle"),
            "url": item.get("webUrl"),
            "section": item.get("sectionName"),
            "published": item.get("webPublicationDate"),
            "description": fields.get("trailText", ""),
            "image": fields.get("thumbnail"),
        })
    return articles


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/news")
def api_news():
    query = request.args.get("query", "")
    section = request.args.get("section", "all")

    try:
        articles = fetch_news(query=query.strip() or None, section=section)
        return jsonify({"status": "ok", "articles": articles})
    except requests.RequestException as exc:
        return jsonify({"status": "error", "message": str(exc)}), 502


if __name__ == "__main__":
    app.run(debug=True)
